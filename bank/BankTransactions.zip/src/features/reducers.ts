import type { CashAction, CashState } from "../interfaces/cashInterfaces";


const initialState: CashState = { count: 0 };

export default function counterReducer(
  state = initialState,
  action: CashAction
): CashState {
  switch (action.type) {
    case 'DECREMENT_BY':      
      return { count: state.count -action.payload };
    case 'INCREMENT_BY':
      return { count: state.count + action.payload };
    default:
      return state;
  }
}
