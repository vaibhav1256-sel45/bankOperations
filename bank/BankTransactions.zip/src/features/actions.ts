
import type { CashAction } from "../interfaces/cashInterfaces";


export const decrementBy = (amount:number): CashAction => ({ type: 'DECREMENT_BY',payload:amount });
export const incrementBy = (amount: number): CashAction => ({
  type: 'INCREMENT_BY',
  payload: amount,
});
