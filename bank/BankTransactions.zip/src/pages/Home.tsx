import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch, RootState } from "../features/store";
import { decrementBy, incrementBy } from "../features/actions";
import { useState } from "react";
import "./Home.css";

function Home() {
  const count = useSelector((state: RootState) => state.count);
  const dispatch = useDispatch<AppDispatch>();
  const [input, setInput] = useState({ deposit: '', withdrawl: '' });

  const deposit = () => {
    if (Number(input.deposit) <= 0) {
      alert("Invalid amount");
      return;
    }
    dispatch(incrementBy(Number(input.deposit)));
    setInput(prev => ({ ...prev, deposit: '' }));
  };

  const withdrawl = () => {
    if (Number(input.withdrawl) < 0) {
      alert("Invalid amount");
      return;
    }
    if (Number(input.withdrawl) > count) {
      alert("Withdrawl amount is more than total amount");
      return;
    }
    dispatch(decrementBy(Number(input.withdrawl)));
    setInput(prev => ({ ...prev, withdrawl: '' }));
  };

  return (
    <div className="bank-root">
      <div className="bank-card">
        <h2 className="bank-title">Bank Account</h2>
        <div className="bank-actions">
          <div className="bank-action">
            <input
              value={input.deposit}
              type="number"
              name="deposit"
              onChange={e => setInput(prev => ({ ...prev, [e.target.name]: e.target.value }))}
              placeholder="Enter deposit amount"
              className="bank-input"
              min="0"
            />
            <button className="bank-btn deposit" onClick={deposit} >Deposit</button>
          </div>
          <div className="bank-action">
            <input
              type="number"
              value={input.withdrawl}
              name="withdrawl"
              onChange={e => setInput(prev => ({ ...prev, [e.target.name]: e.target.value }))}
              placeholder="Enter withdrawl amount"
              className="bank-input"
              min="0"
            />
            <button className="bank-btn withdrawl" onClick={withdrawl}>Withdraw</button>
          </div>
        </div>
        <div className="bank-balance">
          <span>Total Balance</span>
          <span className="bank-balance-amount">{count}</span>
        </div>
      </div>
    </div>
  );
}

export default Home;
