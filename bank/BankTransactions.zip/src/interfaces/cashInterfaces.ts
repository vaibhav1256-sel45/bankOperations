export interface CashState {
    count: number;
  }
  
  export type CashAction =
     { type: 'DECREMENT_BY', payload: number}
    | { type: 'INCREMENT_BY', payload: number };
  